from collections import defaultdict



class Map:
    def __int__(self, links, locations=None, directed=False):
        pass