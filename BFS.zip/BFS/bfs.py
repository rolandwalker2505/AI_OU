import math




def breadth_first_search(problem):
    pass

